jni/ ；包含测试程序alsa_client和alsa_daemon及其源码
assets/ ; 包含需要存入系统中的alsa控制工具，alsa_mixer, alsa_ctl等
alsa-lib 和 alsa-utils ; alsa官方源码，包含liasound.so和assets/中的测试工具
pcm2wav ; pcm转wav的程序，为pcm原始数据加上wav的头，从而可以被直接播放

