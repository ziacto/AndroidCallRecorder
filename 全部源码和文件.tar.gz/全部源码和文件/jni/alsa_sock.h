
#include <sys/socket.h>
#include <sys/un.h>


/* AF_UNIX/SOCK_SEQPACKET socket name for client/server communication. */

//#define FILES_PATH	"/data/data/com.voix/files/"
#define FILES_PATH	"/data/tmp/"
//#define FILES_PATH	"/data/data/com.skvalex.callrecorder/files/"
#define ASOCK_NAME	FILES_PATH "voix_alsa_socket"

#define ALSA_CTL_CMD	"/system/xbin/alsa_ctl"
#define ALSA_MIX_CMD	"/system/xbin/alsa_amixer"

#define DEBUG_CONTEXTS  1
//#undef DEBUG_CONTEXTS

/* Client must send request type followed by request-dependent info, as below */

#define ALSA_DEV_NAME		1	/* to be followed by dev name; response: 1 on success, 0 on error  */
#define ALSA_START_REC		2	/* to be followed by file name; response: ptr to context */
#define ALSA_STOP_REC		3	/* to be followed by ptr to context; response: 1 on success, 0 if context was invalid */
#define ALSA_PING		4	/* to be followed by any int value; response: the same value echoed */
#define ALSA_MIX_FILE		5	/* set mixer config file; same as with ALSA_DEV_NAME */

#ifdef DEBUG_CONTEXTS 
#define ALSA_LIST		6	/* just lists all active recording contexts, if any */
#define ALSA_STOP_ALL		7	/* response: 1 on success, 0 on error */
#endif
#define ALSA_LOAD_CFG		8	/* load currently set config file. response: 1 on success, 0 on error */
#define ALSA_SHOW_CFG		9	/* replies with info about dev/cfg file names*/

